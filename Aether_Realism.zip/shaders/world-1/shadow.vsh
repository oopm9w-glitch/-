#version 330 compatibility
#define AETHER_NETHER
#include "/program/shadow.vsh"
