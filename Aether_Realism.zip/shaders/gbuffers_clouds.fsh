#version 330 compatibility
#include "/program/sky_discard.fsh"
