#version 330 compatibility
#define AETHER_END
#define PASS_WEATHER
#include "/program/overlay.vsh"
