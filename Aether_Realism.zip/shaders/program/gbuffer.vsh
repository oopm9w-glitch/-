#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/math.glsl"
#include "/lib/waves.glsl"
in vec4 mc_Entity;
in vec4 at_tangent;
in vec2 mc_midTexCoord;
out vec2 vTexCoord;
out vec2 vLightCoord;
out vec4 vColor;
out vec3 vRelative;
out vec3 vNormal;
out vec3 vTangent;
flat out float vHandedness;
flat out float vBlockId;
void main() {
    vTexCoord=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
    vLightCoord=clamp((gl_TextureMatrix[1]*gl_MultiTexCoord1).xy,vec2(0.0),vec2(1.0));
    vColor=gl_Color;
    vec4 view=gl_ModelViewMatrix*gl_Vertex;
    vec3 relative=(gbufferModelViewInverse*view).xyz;
    vBlockId=mc_Entity.x;
#if defined(PASS_TERRAIN) || defined(PASS_WATER)
    float topWeight=step(vTexCoord.y,mc_midTexCoord.y);
    relative=animateVertex(relative,vBlockId,topWeight);
#endif
    vRelative=relative;
    vNormal=normalize(mat3(gbufferModelViewInverse)*gl_NormalMatrix*gl_Normal);
    vec3 tangent=mat3(gbufferModelViewInverse)*gl_NormalMatrix*at_tangent.xyz;
    // Non-terrain vertex formats need not supply a tangent attribute.
    if (dot(tangent,tangent)<0.01) {
        tangent=cross(abs(vNormal.y)<0.9?vec3(0,1,0):vec3(0,0,1),vNormal);
    }
    vTangent=normalize(tangent);
    vHandedness=at_tangent.w<0.0?-1.0:1.0;
    // Preserve pass-specific projection, especially the hand's FOV/depth transform.
    gl_Position=gl_ProjectionMatrix*gbufferModelView*vec4(relative,1.0);
}
