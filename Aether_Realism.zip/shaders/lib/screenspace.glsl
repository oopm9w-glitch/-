#ifndef AETHER_SCREENSPACE
#define AETHER_SCREENSPACE
float ambientOcclusion(vec2 uv, vec3 position, vec3 normal) {
#if SSAO == 1
    float angle=hash12(floor(uv*vec2(viewWidth,viewHeight)))*2.0*PI;
    vec3 random=vec3(cos(angle),sin(angle),0.0);
    vec3 tangent=normalize(random-normal*dot(random,normal)+vec3(0.00001));
    mat3 basis=mat3(tangent,cross(normal,tangent),normal);
    float occluded=0.0;
    for (int i=0;i<SSAO_SAMPLES;++i) {
        float f=(float(i)+0.5)/float(SSAO_SAMPLES);
        float a=float(i)*2.399963;
        vec3 hemisphere=vec3(cos(a)*sqrt(f),sin(a)*sqrt(f),sqrt(1.0-f));
        vec3 probe=position+basis*hemisphere*AO_RADIUS*mix(0.15,1.0,f*f);
        vec2 sampleUv=projectView(probe);
        if (any(lessThan(sampleUv,vec2(0.0))) || any(greaterThan(sampleUv,vec2(1.0)))) continue;
        float d=texture(depthtex0,sampleUv).r;
        if (d>=0.999999) continue;
        vec3 sampled=viewPosition(sampleUv,d);
        float range=1.0-smoothstep(AO_RADIUS,AO_RADIUS*2.0,abs(position.z-sampled.z));
        occluded+=step(probe.z+0.035,sampled.z)*range;
    }
    return 1.0-occluded/float(SSAO_SAMPLES)*AO_STRENGTH*0.75;
#else
    return 1.0;
#endif
}
vec3 screenIndirect(vec2 uv, vec3 position, vec3 normal) {
#if SSGI == 1
    vec3 indirect=vec3(0.0);
    float angle=hash12(floor(uv*vec2(viewWidth,viewHeight)))*2.0*PI;
    for (int i=0;i<8;++i) {
        float a=angle+float(i)*2.399963;
        vec2 delta=vec2(cos(a),sin(a))*(4.0+float(i)*2.0)/vec2(viewWidth,viewHeight);
        vec2 sampleUv=clamp(uv+delta,vec2(0.001),vec2(0.999));
        float depth=texture(depthtex0,sampleUv).r;
        if (depth>=0.999999) continue;
        vec3 offset=viewPosition(sampleUv,depth)-position;
        float dist2=max(dot(offset,offset),0.01);
        vec3 sourceNormal=normalize(texture(colortex1,sampleUv).xyz*2.0-1.0);
        vec3 direction=offset*inversesqrt(dist2);
        float geometry=saturate(dot(normal,direction))*saturate(dot(sourceNormal,-direction));
        float weight=geometry/(1.0+dist2*2.0);
        indirect+=min(texture(colortex0,sampleUv).rgb,vec3(3.0))*weight;
    }
    return indirect*(0.3/8.0);
#else
    return vec3(0.0);
#endif
}
// Returns radiance and confidence. Source is the immutable pre-translucent scene.
vec4 traceReflection(vec3 origin, vec3 direction, float roughness, vec2 pixel) {
#if SSR_QUALITY > 0
#if SSR_QUALITY == 1
    const int steps=16;
#else
    const int steps=32;
#endif
    float stepLength=mix(0.35,0.7,roughness);
    vec3 ray=origin+direction*0.15;
    vec3 previous=ray;
    float jitter=hash12(pixel);
    for (int i=0;i<steps;++i) {
        previous=ray;
        ray+=direction*stepLength*(0.7+jitter*0.3);
        stepLength*=1.12;
        if (ray.z>-near) break;
        vec2 uv=projectView(ray);
        if (any(lessThan(uv,vec2(0.002))) || any(greaterThan(uv,vec2(0.998)))) break;
        float d=texture(depthtex1,uv).r;
        if (d>=0.999999) continue;
        float sceneZ=viewPosition(uv,d).z;
        float difference=sceneZ-ray.z;
        if (difference>0.0 && difference<max(0.25,stepLength*1.8)) {
            vec3 lo=previous, hi=ray;
            for (int j=0;j<4;++j) {
                vec3 mid=(lo+hi)*0.5;
                vec2 midUv=clamp(projectView(mid),vec2(0.001),vec2(0.999));
                float z=viewPosition(midUv,texture(depthtex1,midUv).r).z;
                if (z>mid.z) hi=mid; else lo=mid;
            }
            uv=clamp(projectView((hi+lo)*0.5),vec2(0.001),vec2(0.999));
            float edge=min(min(uv.x,uv.y),min(1.0-uv.x,1.0-uv.y));
            float confidence=smoothstep(0.0,0.08,edge)*(1.0-smoothstep(0.35,0.7,roughness));
            return vec4(texture(colortex4,uv).rgb,confidence);
        }
    }
#endif
    return vec4(0.0);
}
#endif
