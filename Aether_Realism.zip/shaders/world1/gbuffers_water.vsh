#version 330 compatibility
#define AETHER_END
#define PASS_WATER
#include "/program/gbuffer.vsh"
