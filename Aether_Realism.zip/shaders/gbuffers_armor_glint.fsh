#version 330 compatibility
#define PASS_EMISSIVE
#include "/program/overlay.fsh"
