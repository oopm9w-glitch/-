#version 330 compatibility
#define PASS_BLOCK
#include "/program/gbuffer.fsh"
