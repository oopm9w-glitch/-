#version 330 compatibility
#define PASS_WEATHER
#include "/program/overlay.fsh"
