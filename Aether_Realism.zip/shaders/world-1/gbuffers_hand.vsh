#version 330 compatibility
#define AETHER_NETHER
#define PASS_HAND
#include "/program/gbuffer.vsh"
