#version 330 compatibility
#define AETHER_END
#include "/program/sky_discard.fsh"
