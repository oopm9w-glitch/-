#version 330 compatibility
#define AETHER_NETHER
#define PASS_WEATHER
#include "/program/overlay.vsh"
