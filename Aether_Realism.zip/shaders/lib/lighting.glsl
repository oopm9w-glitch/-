#ifndef AETHER_LIGHTING
#define AETHER_LIGHTING
vec3 shadeMaterial(Material m, vec3 relative, vec2 lm, float vertexAo) {
    vec3 viewDir=normalize(-relative);
    vec3 lightDir=lightDirection();
    float nl=saturate(dot(m.normal,lightDir));
    float visibility=shadowVisibility(relative,m.normal,nl);
    float skylight=smoothstep(0.0,1.0,lm.y);
    vec3 skyAmbient=mix(vec3(0.012,0.023,0.05),vec3(0.19,0.29,0.43),daylight());
    float hemisphere=mix(0.45,1.0,saturate(m.normal.y*0.5+0.5));
    vec3 ambient=skyAmbient*skylight*hemisphere;
    vec3 direct=celestialLight()*visibility*skylight*directBRDF(m,viewDir,lightDir);
#ifdef AETHER_NETHER
    ambient=vec3(0.12,0.043,0.025)*0.7 + linearColor(fogColor)*0.35;
    direct=vec3(0.0);
#elif defined(AETHER_END)
    ambient=vec3(0.08,0.055,0.14)*hemisphere;
    direct=vec3(0.4,0.26,0.6)*directBRDF(m,viewDir,normalize(vec3(0.4,0.8,-0.3)));
#endif
    float block=pow(saturate(lm.x),3.0)*BLOCKLIGHT_INTENSITY;
    vec3 blockColor=vec3(1.0,0.48,0.15)*block*2.4;
#if HAND_LIGHT == 1
    float held=float(max(heldBlockLightValue,heldBlockLightValue2))/15.0;
    float hand=held*sq(saturate(1.0-length(relative)/14.0));
    blockColor += vec3(1.0,0.58,0.25)*hand*max(0.2,dot(m.normal,viewDir))*1.5;
#endif
    float ao=mix(0.35,1.0,vertexAo)*m.ao;
    vec3 indirect=(ambient*AMBIENT_BRIGHTNESS + blockColor + vec3(0.003))*ao;
    indirect=max(indirect,vec3(nightVision*0.35));
    vec3 result=m.albedo*(1.0-m.metal)*indirect+direct;
    // Lightmap irradiance has no direction; use a bounded specular ambient approximation for metals.
    result+=blockColor*m.f0*m.metal*(0.25+0.75*(1.0-m.roughness));
    float scatter=pow(max(dot(-m.normal,lightDir),0.0),2.0)*m.subsurface;
    result += m.albedo*celestialLight()*scatter*visibility*skylight*0.16;
    result += m.albedo*m.emission*5.0;
    return result;
}
#endif
