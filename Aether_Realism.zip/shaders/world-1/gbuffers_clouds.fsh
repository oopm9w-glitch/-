#version 330 compatibility
#define AETHER_NETHER
#include "/program/sky_discard.fsh"
