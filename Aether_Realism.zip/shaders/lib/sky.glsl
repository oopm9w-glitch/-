#ifndef AETHER_SKY
#define AETHER_SKY
vec3 sunlightColor() {
    float elevation = abs(sunDirection().y);
    vec3 c = mix(vec3(1.0,0.31,0.10),vec3(1.0,0.91,0.77),smoothstep(0.0,0.45,elevation));
    return c * (4.0 * SUN_BRIGHTNESS) * (1.0-0.72*rainStrength);
}
vec3 moonlightColor() { return vec3(0.16,0.25,0.46)*SUN_BRIGHTNESS; }
vec3 celestialLight() { return mix(moonlightColor(), sunlightColor(), daylight()); }
float exteriorVisibility(float skylight) {
#if defined(AETHER_NETHER) || defined(AETHER_END)
    return 1.0; // Sky lightmap is absent in these dimensions; ambient environment still exists.
#else
    return smoothstep(0.5,0.95,skylight);
#endif
}
// Analytic Rayleigh/Mie-inspired atmosphere. HDR until the final pass.
vec3 atmosphere(vec3 dir) {
#ifdef AETHER_NETHER
    return max(linearColor(fogColor),vec3(0.025,0.005,0.003)) * (0.7+0.3*max(dir.y,0.0));
#elif defined(AETHER_END)
    float nebula = fbm(dir*5.0 + vec3(0,frameTimeCounter*0.005,0));
    return mix(vec3(0.012,0.008,0.035),vec3(0.12,0.035,0.17),nebula*nebula);
#else
    vec3 sun = sunDirection();
    float day = daylight(), h = max(dir.y,0.0);
    float horizon = pow(1.0-h,3.0);
    float mu = dot(dir,sun);
    float rayleigh = 0.75*(1.0+mu*mu);
    vec3 zenith = vec3(0.055,0.24,0.55)*rayleigh;
    vec3 horizonColor = vec3(0.46,0.64,0.78);
    float sunset = exp(-abs(sun.y)*7.5);
    float warm = pow(max(dot(dir.xz,normalize(sun.xz+vec2(0.0001))),0.0),4.0);
    horizonColor = mix(horizonColor,vec3(1.1,0.32,0.10),sunset*warm*0.85);
    vec3 daySky = mix(zenith,horizonColor,horizon);
    float mie = 0.015 / pow(max(1.0+0.76*0.76-2.0*0.76*mu,0.02),1.5);
    daySky += sunlightColor()*mie*(0.15+0.85*sunset);
    vec3 nightSky = mix(vec3(0.0015,0.004,0.014),vec3(0.022,0.032,0.065),horizon);
    vec3 sky = mix(nightSky,daySky,day);
    vec3 overcast = mix(vec3(0.01,0.014,0.023),vec3(0.18,0.23,0.29),day);
    sky = mix(sky,overcast*(0.75+0.25*h),rainStrength*0.88);
    return mix(sky*0.35,sky,smoothstep(-0.25,0.02,dir.y));
#endif
}
vec3 skyRadiance(vec3 dir, bool disks) {
    vec3 sky = atmosphere(dir);
#ifndef AETHER_NETHER
    float night = 1.0-daylight();
#ifdef AETHER_END
    night = 1.0;
#endif
    if (dir.y > 0.0) {
        // A 3-D directional cell grid has no polar singularities.
        vec3 cell = floor(dir*450.0), local = fract(dir*450.0)-0.5;
        float star = (1.0-smoothstep(0.0,0.13,length(local)))*step(0.996,hash13(cell));
        sky += mix(vec3(0.55,0.72,1.0),vec3(1.0,0.75,0.48),hash13(cell+17.0))
             *star*night*STAR_BRIGHTNESS*(1.0-rainStrength)*smoothstep(0.0,0.2,dir.y)*1.8;
    }
#ifndef AETHER_END
    if (disks) {
        vec3 s = sunDirection(), m = toWorldDirection(moonPosition);
        float sunDisk = smoothstep(cos(0.006),cos(0.0045),dot(dir,s));
        float moonDisk = smoothstep(cos(0.010),cos(0.008),dot(dir,m));
        // Spherical moon with a changing terminator, including the new-moon phase.
        vec3 right = normalize(cross(m,vec3(0,1,0)) + vec3(0.00001,0,0));
        vec3 up = normalize(cross(right,m));
        vec2 q = vec2(dot(dir,right),dot(dir,up))/0.01;
        float phase = float(moonPhase)*PI*0.25;
        vec3 moonNormal = vec3(q,sqrt(max(1.0-dot(q,q),0.0)));
        float illuminated = saturate(dot(moonNormal,vec3(sin(phase),0.0,cos(phase))));
        sky += sunlightColor()*sunDisk*10.0*(1.0-rainStrength);
        sky += vec3(1.0,1.15,1.5)*moonDisk*(0.025+illuminated)*0.6*(1.0-rainStrength);
    }
#endif
#endif
    return sky;
}
float cloudDensity(vec3 p) {
    float height = (p.y-CLOUD_HEIGHT)/44.0;
    float envelope = smoothstep(0.0,0.18,height)*(1.0-smoothstep(0.55,1.0,height));
    vec3 q = p*0.006 + vec3(frameTimeCounter*0.012,0.0,frameTimeCounter*0.004)*CLOUD_SPEED;
    float shape = fbm(q);
    float coverage = CLOUD_COVERAGE + rainStrength*0.12;
    float density = saturate((shape-(1.0-coverage))*4.5)*envelope;
#if CLOUD_QUALITY >= 2
    density = max(density-(1.0-aetherNoise3(q*6.0))*0.13*envelope,0.0);
#endif
    return density;
}
vec3 renderSky(vec3 dir, vec2 pixel) {
    vec3 background = skyRadiance(dir,true);
#if CLOUD_QUALITY > 0 && !defined(AETHER_NETHER) && !defined(AETHER_END)
    if (dir.y <= 0.005) return background;
    float start = max((CLOUD_HEIGHT-cameraPosition.y)/dir.y,0.0);
    float finish = (CLOUD_HEIGHT+44.0-cameraPosition.y)/dir.y;
    if (finish <= start) return background;
    finish = min(finish,6000.0);
    if (finish <= start) return background;
#if CLOUD_QUALITY == 1
    const int count = 8;
#elif CLOUD_QUALITY == 2
    const int count = 16;
#else
    const int count = 28;
#endif
    float stepLength = (finish-start)/float(count);
    float jitter = hash12(pixel);
    float transmission = 1.0;
    vec3 scattering = vec3(0.0), lightDir = lightDirection();
    vec3 ambient = mix(vec3(0.028,0.044,0.085),vec3(0.32,0.43,0.57),daylight());
    float forwardScatter = pow(max(dot(dir,lightDir),0.0),16.0);
    for (int i=0;i<count;++i) {
        vec3 p = cameraPosition + dir*(start+(float(i)+jitter)*stepLength);
        float density = cloudDensity(p);
        if (density > 0.001) {
            float lightDepth = cloudDensity(p+lightDir*16.0)*1.5;
#if CLOUD_QUALITY >= 2
            lightDepth += cloudDensity(p+lightDir*36.0);
#endif
            float visibility = exp(-lightDepth*2.0);
            vec3 light = ambient + celestialLight()*visibility*(0.18+forwardScatter*0.45);
            float absorbed = 1.0-exp(-density*stepLength*0.055);
            scattering += transmission*absorbed*light;
            transmission *= 1.0-absorbed;
            if (transmission < 0.015) break;
        }
    }
    return background*transmission + scattering;
#else
    return background;
#endif
}
#endif
