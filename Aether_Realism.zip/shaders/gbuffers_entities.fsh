#version 330 compatibility
#define PASS_ENTITY
#include "/program/gbuffer.fsh"
