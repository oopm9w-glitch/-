#version 330 compatibility
#include "/program/bloom_blur.fsh"
