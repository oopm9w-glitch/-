# Changes

## 1.0.1

- Rename the scalar procedural noise function to `aetherNoise3`; `noise3` is a
  GLSL built-in returning `vec3` and failed on the user's strict compiler.
- Declare `RGBA16F` and `RGBA8` in the shaderpack itself while preserving the
  symbolic `colortex*Format` values required by Iris's directive parser.
- Remove buffer-enum injection from the validation harness. Add independent
  glslang validation and a check of preprocessed Iris buffer-format directives.
- Rebuild the installable archive after validation. No changes to the shader
  options, profiles or rendering features.
