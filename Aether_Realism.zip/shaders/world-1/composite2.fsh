#version 330 compatibility
#define AETHER_NETHER
#define BLUR_HORIZONTAL
#include "/program/bloom_blur.fsh"
