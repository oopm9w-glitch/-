#version 330 compatibility
#define AETHER_END
#define BLUR_HORIZONTAL
#include "/program/bloom_blur.fsh"
