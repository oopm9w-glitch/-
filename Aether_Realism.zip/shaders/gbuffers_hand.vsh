#version 330 compatibility
#define PASS_HAND
#include "/program/gbuffer.vsh"
