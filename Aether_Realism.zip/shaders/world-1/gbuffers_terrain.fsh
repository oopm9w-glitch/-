#version 330 compatibility
#define AETHER_NETHER
#define PASS_TERRAIN
#include "/program/gbuffer.fsh"
