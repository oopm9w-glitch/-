#version 330 compatibility
#define PASS_TERRAIN
#include "/program/gbuffer.fsh"
