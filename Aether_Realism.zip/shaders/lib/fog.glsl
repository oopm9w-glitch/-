#ifndef AETHER_FOG
#define AETHER_FOG
vec3 applyFog(vec3 color, vec3 relative, vec3 direction) {
    float distanceToEye=length(relative);
    if (isEyeInWater==1) {
        vec3 trans=exp(-vec3(0.22,0.07,0.035)*distanceToEye/WATER_CLARITY);
        vec3 waterLight=mix(vec3(0.004,0.018,0.03),vec3(0.012,0.12,0.16),daylight());
        return color*trans+waterLight*(1.0-trans);
    }
    if (isEyeInWater==2) return mix(color,vec3(1.8,0.18,0.008),1.0-exp(-distanceToEye*2.0));
    if (isEyeInWater==3) return mix(color,vec3(0.65,0.8,0.95),1.0-exp(-distanceToEye*0.7));
    float density=0.0013*(1.0+rainStrength*4.0)*FOG_DENSITY;
    float altitude=cameraPosition.y+relative.y*0.5;
    density*=exp(-max(altitude-64.0,0.0)*0.012);
    float amount=1.0-exp(-distanceToEye*density);
    // Smoothly conceal the actual render-distance cutoff even when artistic fog is off.
    float renderLimit=smoothstep(far*0.72,far*0.99,length(relative.xz));
    amount=max(amount,renderLimit);
    vec3 fog=atmosphere(direction);
#ifdef AETHER_NETHER
    amount=max(amount,1.0-exp(-distanceToEye*0.018*FOG_DENSITY));
#elif defined(AETHER_END)
    amount=max(amount,1.0-exp(-distanceToEye*0.003*FOG_DENSITY));
#else
    float cave=saturate(float(eyeBrightnessSmooth.y)/240.0);
    fog*=mix(0.04,1.0,cave);
#endif
    return mix(color,fog,saturate(amount));
}
vec3 volumetricScattering(vec3 relative, vec3 direction, vec2 pixel) {
#if VOLUMETRIC_LIGHT == 1 && !defined(AETHER_NETHER) && !defined(AETHER_END)
    if (isEyeInWater!=0) return vec3(0.0);
    float distanceToEye=min(length(relative),min(shadowDistance*0.9,112.0));
    float stepLength=distanceToEye/float(VOLUMETRIC_STEPS);
    float jitter=hash12(pixel);
    float mu=dot(direction,lightDirection()), g=0.65;
    float phase=(1.0-g*g)/(4.0*PI*pow(max(1.0+g*g-2.0*g*mu,0.01),1.5));
    float integral=0.0;
    for (int i=0;i<VOLUMETRIC_STEPS;++i) {
        float d=(float(i)+jitter)*stepLength;
        vec3 p=direction*d;
        float density=exp(-max(cameraPosition.y+p.y-64.0,0.0)*0.015);
        integral+=shaftVisibility(p)*density*exp(-d*0.012);
    }
    return celestialLight()*integral*stepLength*0.0018*(phase+0.035)
         *LIGHT_SHAFT_STRENGTH*(1.0+rainStrength)*FOG_DENSITY;
#else
    return vec3(0.0);
#endif
}
#endif
