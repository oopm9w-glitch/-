uniform sampler2D gtexture;
in vec2 vTexCoord;
in vec4 vColor;
/* DRAWBUFFERS:0 */
void main() {
    vec4 color=texture(gtexture,vTexCoord);
    if (color.a<0.1) discard;
    gl_FragData[0]=vec4(color.rgb*vColor.rgb,1.0);
}
