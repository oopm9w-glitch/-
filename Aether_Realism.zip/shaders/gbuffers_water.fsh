#version 330 compatibility
#define PASS_WATER
#include "/program/gbuffer.fsh"
