# Validation and remaining game checks

## Executed in the development environment

Run `python3 tools/validate.py` from the project root. The machine-readable result
is `validation.json` in this directory. The validator uses the production GLSL
includes with the same profile constants; it does not substitute simplified
versions of the effects.

- Verify 26 complete program pairs in each of three dimensions, include safety,
  one main entrypoint per stage, all 43 options, profile values and three locales.
- Compile and link 78 program pairs for each LOW, MEDIUM and ULTRA configuration.
- Compile and link another 78 pairs with all options at their minimum listed
  values, including effects which the profiles normally keep enabled.
- When glslangValidator is installed, independently check every unique vertex and
  fragment source with it before OpenGL compilation. Use `--glslang PATH` to select
  an executable explicitly. This catches stricter standard GLSL diagnostics that
  Mesa may accept, including conflicting built-in function names.
- Compile the pack's own buffer-format declarations without test-injected
  `RGBA16F`/`RGBA8` definitions, and check that preprocessing preserves the format
  identifiers expected by Iris's render-target directive parser.
- Use a real surfaceless EGL OpenGL compatibility context (Mesa llvmpipe) to draw
  production passes with float framebuffer attachments and deterministic fixtures.
- Assert SSAO reacts to a depth discontinuity; volumetric clouds change the sky
  and move with time; water absorption and rain change the composite output.
- Execute the three HDR bloom passes and final filmic output; assert bloom affects
  the output, exposure is monotonic and final RGB is finite in [0,1].
- Assert the real SSR marcher hits a known opaque plane with nonzero confidence.
- Draw geometry with the actual forward shader; verify lit/shadowed depth maps
  change lighting, labPBR conductor data changes shading, wetness affects an
  upward-facing surface and the water render changes with wave animation.
- Reject NaN/infinite pixels, GL errors, compiler errors and linker errors.

The fixtures are 64×48 pixels and validate functionality, not artistic quality or
game FPS. Iris's shader transformer, actual vertex streams, world/dimension
transitions, resource reload behavior and GPU vendor differences are outside
this harness. **No in-game test was performed.**

## 1.0.1 regression diagnosis

The user's 1.0.0 game log reported a conflicting function return type and undefined
`RGBA16F`/`RGBA8` identifiers in `deferred.fsh`. The original ZIP was extracted and
submitted to glslangValidator without extra format definitions. It reproduced the
`noise3` return-type error; renaming only that function then exposed the undefined
`RGBA16F` error. Both were real shaderpack defects.

The previous Mesa-only harness incorrectly supplied those enums itself and did
not detect Mesa's permissive acceptance of the built-in name collision. Version
1.0.1 uses `aetherNoise3`, declares its own format constants and removes the fake
definitions. The current report records the independent validator as well as
the existing OpenGL and functional checks. This is still not an Iris game run.

## Manual Minecraft acceptance checklist — not yet executed

Use a separate Minecraft 1.21.11 Fabric profile with officially matching Iris and
Sodium builds. Start with vanilla textures and MEDIUM. Save any shader compiler
errors from `logs/latest.log`; record Iris, Sodium and GPU/driver versions.

- Load the ZIP directly; inspect Iris shader errors and switch all three profiles.
- Visit a forest, ocean, village, underground room, snowy biome, Nether and End.
- Inspect sunrise, noon, sunset, midnight and all moon phases.
- Toggle rain and wait for wetness to accumulate and dry out; inspect sky-exposed
  roofs versus sheltered interiors. Check emissive blocks and held torches.
- Check cutout leaf shadows, waving plants, shadow-distance transition and camera
  motion. Watch for acne, light leaks and vegetation anchoring.
- Look at water from above, shore level and underwater. Check flowing water,
  glass, stained glass, foreground occluders, screen edges and the player's hand.
- Check animated and glowing entities, hurt flash, armor glint, beacon beams,
  particles, weather, block selection lines and block-breaking overlays.
- Load a compatible labPBR resource pack; inspect diffuse stone, smooth dielectrics,
  rough/smooth metals, normal orientation, emission and the alpha-255 sentinel.
- Exercise all menu sections, custom values, UI localization, window resize,
  fullscreen, resource reload, shader disable/enable and dimension transitions.
- Inspect night vision, blindness, darkness, underwater, lava and powder snow.
- Record FPS/frame-time and VRAM on actual target hardware. Tune shadow resolution,
  distance, clouds and SSR first. No hardware performance numbers are inferred
  from the software test renderer.

## Package

`python3 tools/build.py` creates a deterministic installable archive and SHA-256
file. The build verifies CRCs, root paths, required programs, source identity and
that no parent-directory wrapper or repository metadata enters the ZIP.
`python3 tools/build.py --verify-only` rechecks an existing archive against source.
