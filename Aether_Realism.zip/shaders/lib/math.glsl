#ifndef AETHER_MATH
#define AETHER_MATH
const float PI = 3.14159265359;
float saturate(float x) { return clamp(x, 0.0, 1.0); }
vec3 saturate(vec3 x) { return clamp(x, 0.0, 1.0); }
float sq(float x) { return x * x; }
float pow5(float x) { float x2 = x * x; return x2 * x2 * x; }
float luminance(vec3 x) { return dot(x, vec3(0.2126, 0.7152, 0.0722)); }
vec3 linearColor(vec3 c) {
    return mix(c / 12.92, pow(max((c + 0.055) / 1.055, vec3(0.0)), vec3(2.4)), step(vec3(0.04045), c));
}
vec3 srgbColor(vec3 c) {
    return mix(c * 12.92, 1.055 * pow(max(c, vec3(0.0)), vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c));
}
float hash12(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}
float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}
float aetherNoise3(vec3 p) {
    vec3 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash13(i), hash13(i + vec3(1,0,0)), f.x),
                   mix(hash13(i + vec3(0,1,0)), hash13(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(hash13(i + vec3(0,0,1)), hash13(i + vec3(1,0,1)), f.x),
                   mix(hash13(i + vec3(0,1,1)), hash13(i + vec3(1,1,1)), f.x), f.y), f.z);
}
float fbm(vec3 p) {
    float v = 0.0, a = 0.55;
    for (int i = 0; i < 4; ++i) {
        v += a * aetherNoise3(p); p = p * 2.03 + vec3(19.1, 7.7, 3.2); a *= 0.48;
    }
    return v;
}
vec3 viewPosition(vec2 uv, float depth) {
    vec4 p = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}
vec2 projectView(vec3 p) {
    vec4 c = gbufferProjection * vec4(p, 1.0);
    return c.xy / c.w * 0.5 + 0.5;
}
vec3 toWorldDirection(vec3 d) { return normalize(mat3(gbufferModelViewInverse) * d); }
vec3 sunDirection() { return toWorldDirection(sunPosition); }
vec3 lightDirection() { return toWorldDirection(shadowLightPosition); }
float daylight() { return smoothstep(-0.12, 0.16, sunDirection().y); }
#endif
