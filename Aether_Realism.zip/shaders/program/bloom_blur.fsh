#include "/lib/settings.glsl"
uniform sampler2D colortex3;
uniform sampler2D colortex5;
uniform float viewWidth;
uniform float viewHeight;
in vec2 texcoord;
#ifdef BLUR_HORIZONTAL
/* DRAWBUFFERS:5 */
#else
/* DRAWBUFFERS:3 */
#endif
vec3 source(vec2 uv) {
#ifdef BLUR_HORIZONTAL
    return texture(colortex3,clamp(uv,vec2(0.001),vec2(0.999))).rgb;
#else
    return texture(colortex5,clamp(uv,vec2(0.001),vec2(0.999))).rgb;
#endif
}
void main() {
    vec3 color=vec3(0.0);
#if BLOOM == 1
#ifdef BLUR_HORIZONTAL
    vec2 axis=vec2(2.0/viewWidth,0.0);
#else
    vec2 axis=vec2(0.0,2.0/viewHeight);
#endif
    // Narrow and wide lobes share the same half-resolution buffers.
    color=source(texcoord)*0.20;
    color+=(source(texcoord+axis*1.4)+source(texcoord-axis*1.4))*0.18;
    color+=(source(texcoord+axis*3.3)+source(texcoord-axis*3.3))*0.10;
    color+=(source(texcoord+axis*7.0)+source(texcoord-axis*7.0))*0.08;
    color+=(source(texcoord+axis*13.0)+source(texcoord-axis*13.0))*0.04;
#endif
    gl_FragData[0]=vec4(color,1.0);
}
