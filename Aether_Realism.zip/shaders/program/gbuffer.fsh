#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/math.glsl"
#include "/lib/waves.glsl"
#include "/lib/shadow.glsl"
#include "/lib/sky.glsl"
#include "/lib/material.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D gtexture;
uniform sampler2D normals;
uniform sampler2D specular;
uniform sampler2D colortex4;
uniform sampler2D depthtex1;
uniform float alphaTestRef;
in vec2 vTexCoord;
in vec2 vLightCoord;
in vec4 vColor;
in vec3 vRelative;
in vec3 vNormal;
in vec3 vTangent;
flat in float vHandedness;
flat in float vBlockId;
/* DRAWBUFFERS:012 */
void main() {
    vec4 tex=texture(gtexture,vTexCoord);
    float alpha=tex.a;
#if !defined(PASS_TERRAIN)
    alpha*=vColor.a;
#endif
    if (alpha<max(alphaTestRef,0.01)) discard;
    vec3 albedo=linearColor(tex.rgb*vColor.rgb);
#ifdef PASS_ENTITY
    albedo=mix(albedo,linearColor(entityColor.rgb),entityColor.a);
#endif
    vec3 geometricNormal=normalize(vNormal);
    if (!gl_FrontFacing) geometricNormal=-geometricNormal;
    Material m=defaultMaterial(albedo,geometricNormal);
#if PBR_MODE == 1 && (defined(PASS_TERRAIN) || defined(PASS_BLOCK) || defined(PASS_WATER))
    vec4 n=texture(normals,vTexCoord), s=texture(specular,vTexCoord);
    vec2 xy=n.xy*2.0-1.0;
    vec3 t=normalize(vTangent-geometricNormal*dot(vTangent,geometricNormal));
    mat3 tbn=mat3(t,normalize(cross(geometricNormal,t))*vHandedness,geometricNormal);
    m.normal=normalize(tbn*vec3(xy,sqrt(max(1.0-dot(xy,xy),0.001))));
    m.ao=n.b;
    if (dot(s.rgb,vec3(1.0))>0.0001 || (s.a>0.0 && s.a<0.999)) {
        m.roughness=max(sq(1.0-s.r),0.035);
        int metal=int(floor(s.g*255.0+0.5));
        m.metal=metal>=230?1.0:0.0;
        m.f0=metal>=230?conductorF0(metal,albedo):vec3(s.g);
        m.subsurface=s.b>64.5/255.0?(s.b-65.0/255.0)/(190.0/255.0):0.0;
        m.emission=s.a<254.5/255.0?s.a*(255.0/254.0):0.0;
    }
#endif
    if (vBlockId>10001.5 && vBlockId<10005.5) m.subsurface=max(m.subsurface,0.4);
    if (vBlockId>10009.5 && vBlockId<10010.5) m.emission=max(m.emission,1.0);
#if WET_SURFACES == 1
    float puddle=smoothstep(0.45,0.7,aetherNoise3((vRelative+cameraPosition)*vec3(0.2,0.04,0.2)));
    float wet=wetness*smoothstep(0.75,0.98,vLightCoord.y)*saturate(geometricNormal.y)*puddle;
    m.albedo*=1.0-wet*0.24;
    m.roughness=mix(m.roughness,0.045,wet);
    m.f0=mix(m.f0,max(m.f0,vec3(0.04)),wet);
#endif
    float waterMask=0.0;
    vec3 color;
#ifdef PASS_WATER
    if (vBlockId>10000.5 && vBlockId<10001.5) {
        waterMask=1.0;
        vec3 wave=waveField((vRelative+cameraPosition).xz);
        if (abs(geometricNormal.y)>0.5) m.normal=normalize(vec3(-wave.y,1.0,-wave.z))*sign(geometricNormal.y);
        m.roughness=0.045; m.f0=vec3(0.0204); m.metal=0.0; m.albedo=vec3(0.0);
        vec2 uv=gl_FragCoord.xy/vec2(viewWidth,viewHeight);
        vec3 view= (gbufferModelView*vec4(vRelative,1.0)).xyz;
        vec3 normalView=normalize(mat3(gbufferModelView)*m.normal);
        vec2 offset=normalView.xy*WATER_REFRACTION*0.035/max(1.0,length(view)*0.025);
        vec2 refracted=clamp(uv+offset,vec2(0.001),vec2(0.999));
        float d=texture(depthtex1,refracted).r;
        vec3 behind=viewPosition(refracted,d);
        if (d<1.0 && behind.z>view.z+0.02) { refracted=uv; d=texture(depthtex1,uv).r; behind=viewPosition(uv,d); }
        float thickness=d>=0.999999?32.0:clamp(length(behind)-length(view),0.0,64.0);
        vec3 transmission=exp(-vec3(0.19,0.065,0.032)*thickness/WATER_CLARITY);
        vec3 scattering=mix(vec3(0.005,0.055,0.08),vec3(0.018,0.16,0.19),daylight())*(0.25+0.75*vLightCoord.y);
        vec3 transmitted=texture(colortex4,refracted).rgb*transmission+scattering*(1.0-transmission);
        vec3 incident=normalize(vRelative), reflected=reflect(incident,m.normal);
        float f=fresnelSchlick(m.f0,dot(-incident,m.normal)).r;
#if WATER_REFLECTIONS == 0
        f=0.0;
#endif
        vec3 reflectedSky=skyRadiance(reflected,false)*exteriorVisibility(vLightCoord.y);
        color=mix(transmitted,reflectedSky,saturate(f*REFLECTION_STRENGTH));
#if !defined(AETHER_NETHER) && !defined(AETHER_END)
        float nl=saturate(dot(m.normal,lightDirection()));
        color+=directBRDF(m,normalize(-vRelative),lightDirection())*celestialLight()
              *shadowVisibility(vRelative,m.normal,nl)*vLightCoord.y;
#endif
        alpha=1.0; // Transmission is resolved above, never double-alpha-blend water.
    } else
#endif
    {
        float ao=1.0;
#ifdef PASS_TERRAIN
        ao=vColor.a;
#endif
        color=shadeMaterial(m,vRelative,vLightCoord,ao);
    }
    gl_FragData[0]=vec4(max(color,vec3(0.0)),alpha);
    gl_FragData[1]=vec4(normalize(mat3(gbufferModelView)*m.normal)*0.5+0.5,m.roughness);
    // F0 is RGB (colored metals retained); alpha is a water tag or exterior skylight.
    gl_FragData[2]=vec4(m.f0,waterMask>0.5?1.0:min(vLightCoord.y,0.99));
}
