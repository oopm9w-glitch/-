#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/math.glsl"
#include "/lib/waves.glsl"
#include "/lib/shadow.glsl"
in vec4 mc_Entity;
in vec2 mc_midTexCoord;
out vec2 vTexCoord;
out vec4 vColor;
void main() {
    vTexCoord=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
    vColor=gl_Color;
    vec4 view=gl_ModelViewMatrix*gl_Vertex;
    vec3 relative=(shadowModelViewInverse*view).xyz;
    relative=animateVertex(relative,mc_Entity.x,step(vTexCoord.y,mc_midTexCoord.y));
    vec4 clip=shadowProjection*shadowModelView*vec4(relative,1.0);
    clip.xyz=distortShadow(clip.xyz/clip.w)*clip.w;
    gl_Position=clip;
}
