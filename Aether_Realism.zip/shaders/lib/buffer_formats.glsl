#ifndef AETHER_BUFFER_FORMATS
#define AETHER_BUFFER_FORMATS
// These are shaderpack constants, not GLSL built-ins or injected Iris macros.
// Keep the colortex*Format values as enum names: Iris parses those identifiers.
// Using const declarations rather than #define preserves the names through preprocessing.
const int RGBA8 = 32856;
const int RGBA16F = 34842;
#endif
