#ifndef AETHER_SETTINGS
#define AETHER_SETTINGS

// AETHER REALISM 1.0.1 — options parsed by Iris. Keep literal value lists.
#define SUN_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define AMBIENT_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define BLOCKLIGHT_INTENSITY 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define HAND_LIGHT 1 // [0 1]
#define PBR_MODE 1 // [0 1]
#define SSGI 0 // [0 1]
#define SHADOW_QUALITY 8 // [4 8 16]
#define SHADOW_SOFTNESS 1.5 // [0.5 1.0 1.5 2.0 3.0]
const int shadowMapResolution = 2048; // [1024 2048 4096]
const float shadowDistance = 128.0; // [64.0 96.0 128.0 192.0]
#define WATER_WAVES 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define WAVE_SPEED 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define WATER_CLARITY 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define WATER_REFRACTION 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define WATER_REFLECTIONS 1 // [0 1]
#define CLOUD_QUALITY 2 // [0 1 2 3]
#define CLOUD_COVERAGE 0.48 // [0.25 0.35 0.48 0.6 0.7]
#define CLOUD_HEIGHT 192.0 // [128.0 160.0 192.0 256.0]
#define CLOUD_SPEED 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define STAR_BRIGHTNESS 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define FOG_DENSITY 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0]
#define VOLUMETRIC_LIGHT 1 // [0 1]
#define VOLUMETRIC_STEPS 8 // [6 8 16]
#define LIGHT_SHAFT_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define SSR_QUALITY 1 // [0 1 2]
#define REFLECTION_STRENGTH 1.0 // [0.0 0.5 0.75 1.0 1.25]
#define WET_SURFACES 1 // [0 1]
#define BLOOM 1 // [0 1]
#define BLOOM_STRENGTH 0.12 // [0.0 0.06 0.12 0.2 0.3]
#define BLOOM_THRESHOLD 1.0 // [0.6 0.8 1.0 1.5 2.0]
#define EXPOSURE 1.0 // [0.5 0.7 0.85 1.0 1.2 1.5 2.0]
#define SATURATION 1.03 // [0.0 0.7 0.9 1.0 1.03 1.1 1.2]
#define CONTRAST 1.0 // [0.8 0.9 1.0 1.1 1.2]
#define WHITE_BALANCE 0.0 // [-1.0 -0.5 0.0 0.5 1.0]
#define VIGNETTE 0.15 // [0.0 0.1 0.15 0.25 0.35]
#define DITHER 1 // [0 1]
#define FXAA 1 // [0 1]
#define SSAO 1 // [0 1]
#define SSAO_SAMPLES 8 // [4 8 16]
#define AO_STRENGTH 0.7 // [0.0 0.4 0.7 1.0 1.3]
#define AO_RADIUS 1.0 // [0.5 1.0 1.5 2.0]
#define WIND 1 // [0 1]
#define WIND_STRENGTH 1.0 // [0.5 1.0 1.5 2.0]

const float sunPathRotation = -25.0;
const float shadowIntervalSize = 2.0;
const bool shadowHardwareFiltering = false;
const bool shadowtex0Nearest = true;
const float ambientOcclusionLevel = 1.0;
const float wetnessHalflife = 60.0;
const float drynessHalflife = 120.0;
const float eyeBrightnessHalflife = 4.0;

#endif
