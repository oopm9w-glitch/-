#version 330 compatibility
#define AETHER_NETHER
#define PASS_WATER
#include "/program/gbuffer.fsh"
