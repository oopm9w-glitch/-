#version 330 compatibility
#define BLUR_HORIZONTAL
#include "/program/fullscreen.vsh"
