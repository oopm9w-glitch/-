#include "/lib/settings.glsl"
uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
in vec2 texcoord;
/* DRAWBUFFERS:3 */
void main() {
    vec3 bloom=vec3(0.0);
#if BLOOM == 1
    vec2 pixel=1.0/vec2(viewWidth,viewHeight);
    // Prefilter before reducing resolution to avoid single-pixel fireflies.
    for (int y=-1;y<=1;++y) for (int x=-1;x<=1;++x) {
        vec3 c=texture(colortex0,texcoord+vec2(x,y)*pixel).rgb;
        float brightness=max(max(c.r,c.g),c.b);
        float soft=clamp(brightness-BLOOM_THRESHOLD+0.5,0.0,1.0);
        float contribution=max(brightness-BLOOM_THRESHOLD,soft*soft*0.25)/max(brightness,0.0001);
        bloom+=c*contribution/9.0;
    }
#endif
    gl_FragData[0]=vec4(bloom,1.0);
}
