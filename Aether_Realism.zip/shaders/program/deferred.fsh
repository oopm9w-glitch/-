#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/math.glsl"
#include "/lib/buffer_formats.glsl"
#include "/lib/sky.glsl"
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex4;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
#include "/lib/screenspace.glsl"
in vec2 texcoord;
// Scene and its pre-translucent copy. Metadata is not ping-ponged here.
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16F;
const int colortex2Format = RGBA8;
const int colortex3Format = RGBA16F;
const int colortex4Format = RGBA16F;
const int colortex5Format = RGBA16F;
const vec4 colortex0ClearColor = vec4(0.0,0.0,0.0,1.0);
const vec4 colortex1ClearColor = vec4(0.5,0.5,1.0,1.0);
const vec4 colortex2ClearColor = vec4(0.04,0.04,0.04,0.0);
const bool colortex0Clear = true;
const bool colortex1Clear = true;
const bool colortex2Clear = true;
const bool colortex3Clear = true;
const bool colortex4Clear = true;
const bool colortex5Clear = true;
/* DRAWBUFFERS:04 */
void main() {
    float depth=texture(depthtex0,texcoord).r;
    vec3 position=viewPosition(texcoord,depth);
    vec3 color=texture(colortex0,texcoord).rgb;
    if (depth>=0.999999) {
        color=renderSky(toWorldDirection(position),gl_FragCoord.xy);
    } else {
        vec3 normal=normalize(texture(colortex1,texcoord).xyz*2.0-1.0);
        color*=ambientOcclusion(texcoord,position,normal);
        color+=screenIndirect(texcoord,position,normal);
    }
    gl_FragData[0]=vec4(max(color,vec3(0.0)),1.0);
    gl_FragData[1]=vec4(max(color,vec3(0.0)),1.0);
}
