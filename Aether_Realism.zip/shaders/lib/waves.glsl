#ifndef AETHER_WAVES
#define AETHER_WAVES
// Analytic derivatives keep geometry and shading waves in phase.
vec3 waveField(vec2 p) {
    float t = frameTimeCounter * WAVE_SPEED;
    vec2 d0 = normalize(vec2(0.84, 0.54));
    vec2 d1 = normalize(vec2(-0.42, 0.91));
    vec2 d2 = normalize(vec2(0.22, -0.98));
    vec3 k = vec3(0.75, 1.45, 2.8);
    vec3 phase = vec3(dot(p,d0), dot(p,d1), dot(p,d2)) * k - t * vec3(1.1,1.65,2.2);
    vec3 a = vec3(0.035,0.018,0.008) * WATER_WAVES;
    float h = dot(sin(phase), a);
    vec3 derivative = cos(phase) * a * k;
    return vec3(h, derivative.x*d0 + derivative.y*d1 + derivative.z*d2);
}
vec3 animateVertex(vec3 relative, float id, float topWeight) {
    vec3 p = relative + cameraPosition;
    if (id > 10000.5 && id < 10001.5) relative.y += waveField(p.xz).x;
#if WIND == 1
    float strength = 0.0;
    if (id > 10001.5 && id < 10002.5) strength = topWeight * 0.065;
    if (id > 10002.5 && id < 10003.5) strength = 0.045;
    if (id > 10003.5 && id < 10004.5) strength = topWeight * 0.035;
    if (id > 10004.5 && id < 10005.5) strength = (1.0 + topWeight) * 0.035;
    float t = frameTimeCounter;
    float gust = sin(t*1.3 + p.x*0.27 + p.z*0.19) + 0.45*sin(t*2.4 - p.z*0.52);
    relative.xz += vec2(gust, sin(t*1.1+p.x*0.35)) * strength * WIND_STRENGTH * (1.0+rainStrength);
#endif
    return relative;
}
#endif
