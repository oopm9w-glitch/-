#version 330 compatibility
#define AETHER_END
#define PASS_EMISSIVE
#include "/program/overlay.vsh"
