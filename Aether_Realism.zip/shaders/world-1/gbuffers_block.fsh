#version 330 compatibility
#define AETHER_NETHER
#define PASS_BLOCK
#include "/program/gbuffer.fsh"
