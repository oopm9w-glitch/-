#version 330 compatibility
#define BLUR_HORIZONTAL
#include "/program/bloom_blur.fsh"
