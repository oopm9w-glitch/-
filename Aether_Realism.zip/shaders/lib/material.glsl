#ifndef AETHER_MATERIAL
#define AETHER_MATERIAL
struct Material {
    vec3 albedo;
    vec3 normal;
    vec3 f0;
    float roughness;
    float metal;
    float emission;
    float ao;
    float subsurface;
};
vec3 conductorF0(int metal, vec3 albedo) {
    vec3 n, k;
    if (metal==230) { n=vec3(2.9114,2.9497,2.5845); k=vec3(3.0893,2.9318,2.7670); }
    else if (metal==231) { n=vec3(0.18299,0.42108,1.3734); k=vec3(3.4242,2.3459,1.7704); }
    else if (metal==232) { n=vec3(1.3456,0.96521,0.61722); k=vec3(7.4746,6.3995,5.3031); }
    else if (metal==233) { n=vec3(3.1071,3.1812,2.3230); k=vec3(3.3314,3.3291,3.1350); }
    else if (metal==234) { n=vec3(0.27105,0.67693,1.3164); k=vec3(3.6092,2.6248,2.2921); }
    else if (metal==235) { n=vec3(1.91,1.83,1.44); k=vec3(3.51,3.4,3.18); }
    else if (metal==236) { n=vec3(2.3757,2.0847,1.8453); k=vec3(4.2655,3.7153,3.1365); }
    else if (metal==237) { n=vec3(0.15943,0.14512,0.13547); k=vec3(3.9291,3.19,2.3808); }
    else return albedo;
    return ((n-1.0)*(n-1.0)+k*k) / ((n+1.0)*(n+1.0)+k*k);
}
Material defaultMaterial(vec3 albedo, vec3 normal) {
    Material m;
    m.albedo=albedo; m.normal=normal; m.f0=vec3(0.04);
    m.roughness=0.75; m.metal=0.0; m.emission=0.0; m.ao=1.0; m.subsurface=0.0;
    return m;
}
vec3 fresnelSchlick(vec3 f0, float cosine) { return f0+(1.0-f0)*pow5(1.0-saturate(cosine)); }
vec3 directBRDF(Material m, vec3 viewDir, vec3 lightDir) {
    float nl = saturate(dot(m.normal,lightDir)), nv=max(dot(m.normal,viewDir),0.001);
    vec3 h = normalize(viewDir+lightDir+vec3(0.000001));
    float nh=saturate(dot(m.normal,h)), vh=saturate(dot(viewDir,h));
    // m.roughness is already linear alpha (labPBR perceptual smoothness squared).
    float a=max(m.roughness,0.035), a2=a*a;
    float d=a2/(PI*sq(nh*nh*(a2-1.0)+1.0));
    float gv=2.0*nv/(nv+sqrt(a2+(1.0-a2)*nv*nv));
    float gl=2.0*nl/(nl+sqrt(a2+(1.0-a2)*nl*nl)+0.0001);
    vec3 f=fresnelSchlick(m.f0,vh);
    vec3 diffuse=m.albedo*(1.0-f)*(1.0-m.metal)/PI;
    vec3 spec=d*gv*gl*f/max(4.0*nv*nl,0.001);
    return (diffuse+spec)*nl;
}
#endif
