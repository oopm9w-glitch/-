#version 330 compatibility
#define AETHER_END
#define PASS_TERRAIN
#include "/program/gbuffer.fsh"
