#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/math.glsl"
uniform sampler2D gtexture;
in vec2 vTexCoord;
in vec4 vColor;
/* DRAWBUFFERS:0 */
void main() {
    vec4 c=texture(gtexture,vTexCoord)*vColor;
    if (c.a<0.005) discard;
    vec3 rgb=linearColor(c.rgb);
#ifdef PASS_EMISSIVE
    rgb*=4.0;
#elif defined(PASS_WEATHER)
    rgb*=mix(0.18,0.85,daylight());
#endif
    gl_FragData[0]=vec4(rgb,c.a);
}
