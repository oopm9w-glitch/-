#version 330 compatibility
#define AETHER_END
#define PASS_BLOCK
#include "/program/gbuffer.fsh"
