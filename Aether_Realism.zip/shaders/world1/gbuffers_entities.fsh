#version 330 compatibility
#define AETHER_END
#define PASS_ENTITY
#include "/program/gbuffer.fsh"
