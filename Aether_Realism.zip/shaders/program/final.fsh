#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
uniform sampler2D colortex0;
uniform sampler2D colortex3;
#include "/lib/math.glsl"
in vec2 texcoord;
vec3 toneMap(vec3 hdr) {
    hdr*=EXPOSURE*vec3(1.0+WHITE_BALANCE*0.1,1.0,1.0-WHITE_BALANCE*0.1);
    // Fitted filmic shoulder; all scene lighting and bloom are linear before this point.
    vec3 c=clamp((hdr*(2.51*hdr+0.03))/(hdr*(2.43*hdr+0.59)+0.14),0.0,1.0);
    c=mix(vec3(luminance(c)),c,SATURATION);
    c=(c-0.5)*CONTRAST+0.5;
    return srgbColor(saturate(c));
}
vec3 displayColor(vec2 uv) {
    vec3 hdr=texture(colortex0,uv).rgb;
#if BLOOM == 1
    hdr+=texture(colortex3,uv).rgb*BLOOM_STRENGTH;
#endif
    return toneMap(max(hdr,vec3(0.0)));
}
void main() {
    vec3 color=displayColor(texcoord);
#if FXAA == 1
    vec2 pixel=1.0/vec2(viewWidth,viewHeight);
    vec3 nw=displayColor(texcoord+vec2(-1,1)*pixel), ne=displayColor(texcoord+pixel);
    vec3 sw=displayColor(texcoord-pixel), se=displayColor(texcoord+vec2(1,-1)*pixel);
    float l=luminance(color), lnw=luminance(nw), lne=luminance(ne), lsw=luminance(sw), lse=luminance(se);
    float minL=min(l,min(min(lnw,lne),min(lsw,lse))), maxL=max(l,max(max(lnw,lne),max(lsw,lse)));
    if (maxL-minL>max(0.03,maxL*0.12)) {
        vec2 direction=vec2(-((lnw+lne)-(lsw+lse)),(lnw+lsw)-(lne+lse));
        float reduce=max((lnw+lne+lsw+lse)*0.03125,0.0078125);
        direction=clamp(direction/(min(abs(direction.x),abs(direction.y))+reduce),vec2(-8.0),vec2(8.0))*pixel;
        vec3 a=0.5*(displayColor(texcoord-direction/6.0)+displayColor(texcoord+direction/6.0));
        vec3 b=a*0.5+0.25*(displayColor(texcoord-direction*0.5)+displayColor(texcoord+direction*0.5));
        float lb=luminance(b); color=(lb<minL || lb>maxL)?a:b;
    }
#endif
    vec2 centered=texcoord*2.0-1.0;
    color*=1.0-VIGNETTE*smoothstep(0.25,1.7,dot(centered,centered));
#if DITHER == 1
    color+=(hash12(gl_FragCoord.xy)-0.5)/255.0;
#endif
    gl_FragColor=vec4(saturate(color),1.0);
}
