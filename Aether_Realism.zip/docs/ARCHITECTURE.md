# Rendering contract

AETHER REALISM uses Iris's legacy-compatible GLSL 330 vertex/fragment program
interface. Root programs target the Overworld. Complete `world-1` and `world1`
program sets define the Nether/End variants before including shared source.
No Fabric entrypoint, resource-pack metadata, compute extension, external texture,
custom Java renderer, or invented shader API is required.

## Pass order

1. `shadow`: animate the same vertices as terrain, alpha-clip the atlas, render
   a radially warped, depth-compressed shadow map. Translucent shadow casting is
   disabled. Dimension-specific properties disable Nether/End shadow programs.
2. `gbuffers_*`: reconstruct camera-relative world positions, animate vegetation,
   decode optional labPBR maps and evaluate forward GGX/direct + ambient lighting.
   Opaque geometry writes HDR color, normals/roughness and RGB F0/exterior metadata.
   Vanilla sky/cloud programs discard: the deferred pass owns the background.
3. `deferred`: read opaque scene/depth, apply hemisphere SSAO and optional local
   screen-space bounce; generate sky, celestial bodies and volume clouds where
   depth is clear. Write the lit scene to both `colortex0` and `colortex4`.
4. `gbuffers_water`: Iris renders translucents after deferred. Water samples the
   immutable `colortex4` snapshot and `depthtex1`; it resolves refraction,
   absorption, sky Fresnel and direct specular into a fully composited color.
   Water writes alpha 1 so transmission is not applied a second time by blending.
   Other translucent materials retain their texture alpha. Overlay programs write
   only scene color so particles/glints/weather never overwrite surface metadata.
5. `composite`: march screen-space reflection rays against opaque `depthtex1`,
   source reflected color from `colortex4`, and combine Fresnel with a sky fallback.
   Water replaces its existing sky-reflection term; it does not add it twice.
   Apply atmosphere, liquid absorption, shadow-map-integrated shafts and status effects.
6. `composite1`: bright-pass prefilter and reduce to half resolution.
7. `composite2`: horizontal, dual-lobe bloom filter to a second half-size buffer.
8. `composite3`: vertical bloom filter, back to the first half-size buffer.
9. `final`: combine linear bloom/scene, manual exposure, filmic curve, color grading,
   linear-to-sRGB conversion, FXAA, vignette, output dithering. Alpha is 1.

Iris performs the normal deferred/composite ping-pong flips. No pass samples the
same physical image to which it writes; water/SSR use a dedicated opaque snapshot.

## Buffers

| Name | Format / size | Meaning |
| --- | --- | --- |
| colortex0 | RGBA16F / full | Linear HDR scene; alpha is transparency in gbuffers |
| colortex1 | RGBA16F / full | RGB view normal mapped to [0,1]; A linear GGX roughness |
| colortex2 | RGBA8 / full | RGB material F0; A exterior skylight, clamped to 0.99, or 1 for water |
| colortex3 | RGBA16F / half | Bloom extract / completed blur |
| colortex4 | RGBA16F / full | Immutable lit opaque scene, including sky and clouds |
| colortex5 | RGBA16F / half | Horizontal bloom intermediate |
| depthtex0 | Iris depth | Current scene, including translucent depth |
| depthtex1 | Iris depth | Scene without translucent objects, for refraction/SSR |
| shadowtex0 | Iris shadow depth | Opaque alpha-clipped shadow casters |

Buffer-specific blend overrides on the water/hand-water programs keep roughness
and water classification from being corrupted by alpha blending. Buffers are
cleared per frame; no temporal history or camera-reprojection state is used.

## Material and coordinate conventions

`vRelative` is camera-relative world space, `cameraPosition + vRelative` is absolute
world space for waves/noise. Normals and tangents are transformed into world space
for lighting; encoded normals are transformed into view space for SSAO/SSR.
Wave normals are analytic derivatives of the same three sinusoidal components
used for water displacement. Shadow and terrain animations share `waves.glsl`.

labPBR roughness is `(1 - smoothness)^2`, used directly as GGX alpha (not squared
again before the GGX alpha-squared term). Dielectric G values 0–229 store F0;
230–237 use conductor n/k presets, and the remaining metal IDs use albedo F0.
Normal B stores material AO. Specular alpha 255 is ignored as specified by labPBR.
Height/parallax and porosity are not implemented. Rain wetness is procedural.

Settings are centralized in `lib/settings.glsl`; Iris reads literal option lists
and the `profile.*`/`screen.*` declarations in `shaders.properties`. All 43 options
are referenced by rendering code and exposed in the settings menu.
