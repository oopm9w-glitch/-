#version 330 compatibility
#define AETHER_NETHER
#define PASS_ENTITY
#include "/program/gbuffer.vsh"
