# Compatibility research

Checked during development for the requested **Minecraft Java 1.21.11 / Fabric**
target. These are interface references, not third-party shader code bundled in
this project.

- [Official Iris 1.21.11 branch](https://github.com/IrisShaders/Iris/tree/1.21.11)
  — observed HEAD `0a1fcaae55099356bf53410b4f5302753edb0ffc`.
- [Iris build configuration](https://github.com/IrisShaders/Iris/blob/0a1fcaae55099356bf53410b4f5302753edb0ffc/build.gradle.kts)
  — source version 1.10.8, Minecraft 1.21.11, Java 21, build-time Fabric Loader
  0.18.1, Sodium dependency `sodium-fabric-0.8.14+mc1.21.11.jar`.
- [Fabric metadata](https://github.com/IrisShaders/Iris/blob/0a1fcaae55099356bf53410b4f5302753edb0ffc/common/src/main/resources/fabric.mod.json)
  — Sodium dependency `0.8.x`; Iris identifies incompatibilities with OptiFabric
  and Canvas. The build-time loader version is not the metadata minimum.
- [Iris ShaderDoc](https://github.com/IrisShaders/ShaderDoc)
  — purpose and conventions of the Iris/OptiFine shaderpack interface.
- [Iris ShaderProperties implementation](https://github.com/IrisShaders/Iris/blob/0a1fcaae55099356bf53410b4f5302753edb0ffc/common/src/main/java/net/irisshaders/iris/shaderpack/properties/ShaderProperties.java)
  — profiles, settings screens, per-buffer blending and conditional programs.
- [Iris CommonUniforms implementation](https://github.com/IrisShaders/Iris/blob/0a1fcaae55099356bf53410b4f5302753edb0ffc/common/src/main/java/net/irisshaders/iris/uniforms/CommonUniforms.java)
  — weather, eye brightness, liquid/status uniforms.
- [Iris sampler bindings](https://github.com/IrisShaders/Iris/blob/0a1fcaae55099356bf53410b4f5302753edb0ffc/common/src/main/java/net/irisshaders/iris/samplers/IrisSamplers.java)
  — `gtexture`, `normals`, `specular`, opaque/translucent depth conventions.
- [Shader program/uniform reference](https://github.com/sp614x/optifine/blob/master/OptiFineDoc/doc/shaders.txt)
  and [properties reference](https://github.com/sp614x/optifine/blob/master/OptiFineDoc/doc/shaders.properties)
  — legacy program names, DRAWBUFFERS, formats, matrices, option/profile syntax.
- [labPBR normal texture specification](https://github.com/rre36/lab-pbr/wiki/Normal-Texture-Details)
  and [specular texture specification](https://github.com/rre36/lab-pbr/wiki/Specular-Texture-Details)
  — channel encoding, conductor optical constants and emission sentinel.
- [Sodium stable tag for 1.21.11](https://github.com/CaffeineMC/sodium/tree/mc1.21.11-0.8.14)
  and [official release list](https://github.com/CaffeineMC/sodium/releases).

The official Modrinth version endpoints and website were requested, but the
cloud proxy returned a destination-policy 403. No latest published Iris version
is inferred from source alone. The source branch identifies a compatible target,
not proof of a released binary or a Minecraft runtime test.

Official installation/download starting points:

- [Iris](https://irisshaders.dev/)
- [Iris release filtering](https://modrinth.com/mod/iris/versions?g=1.21.11&l=fabric)
- [Sodium release filtering](https://modrinth.com/mod/sodium/versions?g=1.21.11&l=fabric)
- [Fabric installer](https://fabricmc.net/use/installer/)

Keep TLS/certificate and package verification enabled. Install no JAR supplied
by this shaderpack: the archive only contains shader source and documentation.
