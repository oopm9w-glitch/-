#ifndef AETHER_SHADOW
#define AETHER_SHADOW
vec3 distortShadow(vec3 p) {
    float factor = mix(0.15, 1.0, length(p.xy));
    return vec3(p.xy / factor, p.z * 0.2);
}
vec3 shadowCoordinate(vec3 relative) {
    vec4 p = shadowProjection * shadowModelView * vec4(relative, 1.0);
    return distortShadow(p.xyz / p.w) * 0.5 + 0.5;
}
float shadowTap(vec3 coord, vec2 offset) {
    return step(coord.z, texture(shadowtex0, coord.xy + offset).r);
}
float shadowVisibility(vec3 relative, vec3 normal, float nDotL) {
#if defined(AETHER_NETHER) || defined(AETHER_END)
    return 1.0;
#else
    // Normal offset is measured in world blocks; depth bias in distorted shadow space.
    vec3 coord = shadowCoordinate(relative + normal * (0.025 + 0.04*(1.0-nDotL)));
    if (any(lessThan(coord,vec3(0.002))) || any(greaterThan(coord,vec3(0.998)))) return 1.0;
    coord.z -= 0.00011 + 0.0002 * (1.0 - nDotL);
    float angle = hash12(floor((relative.xz+cameraPosition.xz)*16.0))*2.0*PI;
    mat2 rotation = mat2(cos(angle),-sin(angle),sin(angle),cos(angle));
    float radius = SHADOW_SOFTNESS / float(shadowMapResolution);
    float visibility = 0.0;
    for (int i=0; i<SHADOW_QUALITY; ++i) {
        float a = float(i)*2.399963;
        vec2 disk = vec2(cos(a),sin(a))*sqrt((float(i)+0.5)/float(SHADOW_QUALITY));
        visibility += shadowTap(coord, rotation*disk*radius);
    }
    visibility /= float(SHADOW_QUALITY);
    float fade = smoothstep(shadowDistance*0.75, shadowDistance, length(relative.xz));
    return mix(visibility, 1.0, fade);
#endif
}
float shaftVisibility(vec3 relative) {
    vec3 s = shadowCoordinate(relative);
    if (any(lessThan(s,vec3(0.001))) || any(greaterThan(s,vec3(0.999)))) return 1.0;
    s.z -= 0.00015;
    return shadowTap(s, vec2(0.0));
}
#endif
