#version 330 compatibility
#include "/program/bloom_extract.fsh"
