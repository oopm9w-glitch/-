#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/math.glsl"
#include "/lib/shadow.glsl"
#include "/lib/sky.glsl"
#include "/lib/material.glsl"
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex4;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
#include "/lib/screenspace.glsl"
#include "/lib/fog.glsl"
in vec2 texcoord;
/* DRAWBUFFERS:0 */
void main() {
    float depth=texture(depthtex0,texcoord).r;
    vec3 view=viewPosition(texcoord,depth);
    vec3 direction=toWorldDirection(view);
    vec3 relative=(gbufferModelViewInverse*vec4(view,1.0)).xyz;
    vec3 color=texture(colortex0,texcoord).rgb;
    if (depth<0.999999) {
        vec4 encoded=texture(colortex1,texcoord);
        vec3 normal=normalize(encoded.xyz*2.0-1.0);
        vec4 material=texture(colortex2,texcoord);
        bool water=material.a>0.995;
        vec3 reflectedView=reflect(normalize(view),normal);
        vec3 reflectionWorld=toWorldDirection(reflectedView);
        float exterior=exteriorVisibility(material.a);
        vec3 sky=skyRadiance(reflectionWorld,false)*exterior;
        vec4 reflection=vec4(0.0);
        if (encoded.a<0.65) reflection=traceReflection(view+normal*0.08,reflectedView,encoded.a,gl_FragCoord.xy);
        vec3 radiance=mix(sky,reflection.rgb,reflection.a);
        vec3 fresnel=fresnelSchlick(material.rgb,saturate(dot(-normalize(view),normal)));
        float smoothness=1.0-smoothstep(0.05,0.65,encoded.a);
        if (water) {
#if WATER_REFLECTIONS == 1
            // Replace the sky term already integrated by the water pass, avoiding double reflections.
            color+=(radiance-sky)*saturate(fresnel*REFLECTION_STRENGTH);
#endif
        } else {
            // Rough conductors still receive broad environment lighting instead of turning black.
            float conductor=smoothstep(0.45,0.9,max(max(material.r,material.g),material.b));
            vec3 broad=atmosphere(toWorldDirection(normal))*exterior;
            vec3 environment=mix(radiance,broad,encoded.a*conductor);
            color+=environment*fresnel*mix(smoothness,0.6,conductor)*REFLECTION_STRENGTH;
        }
    }
    // For background pixels use a finite atmospheric path, not an infinite projection.
    if (depth>=0.999999) relative=direction*far;
    if (depth<0.999999 || isEyeInWater!=0) color=applyFog(color,relative,direction);
    color+=volumetricScattering(relative,direction,gl_FragCoord.xy);
    color*=1.0-saturate(blindness);
    color*=1.0-saturate(max(darknessFactor,darknessLightFactor))*0.85;
    gl_FragData[0]=vec4(max(color,vec3(0.0)),1.0);
}
