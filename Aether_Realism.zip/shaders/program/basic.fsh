in vec4 vColor;
/* DRAWBUFFERS:0 */
void main() { gl_FragData[0]=vColor; }
